package com.phetsamone.weeklyplanner;

import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

public class ReminderReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        String title = intent.getStringExtra("title");
        String body = intent.getStringExtra("body");

        Intent open = context.getPackageManager()
            .getLaunchIntentForPackage(context.getPackageName());

        PendingIntent contentIntent = null;
        if (open != null) {
            contentIntent = PendingIntent.getActivity(
                context, 0, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
            );
        }

        NotificationCompat.Builder builder =
            new NotificationCompat.Builder(context, ReminderScheduler.CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(title == null ? "ถึงเวลางานแล้ว" : title)
                .setContentText(body == null ? "เปิดแอปเพื่อดูรายละเอียด" : body)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true);

        if (contentIntent != null) builder.setContentIntent(contentIntent);

        NotificationManagerCompat.from(context)
            .notify((int)(System.currentTimeMillis() & 0x7fffffff), builder.build());
    }
}
